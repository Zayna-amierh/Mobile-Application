package com.example.studentplanadvisor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ComingSoonActivity : AppCompatActivity() {
    /**
    This Activity will be used for the future when creating sections for other majors
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coming_soon)
    }
}
